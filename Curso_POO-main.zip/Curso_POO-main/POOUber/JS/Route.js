function Route() {
    this.id;
    this.init;
    this.end;
}