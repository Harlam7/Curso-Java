class UberX extends CarBasic {

    constructor(license, driver, brand, model) {

        super(license, driver, brand, model);        

    }

}