class UberSUV extends CarAdvanced {

    constructor(license, driver, typeCarAccepted, seatsMaterial) {

        super(license, driver, typeCarAccepted, seatsMaterial);

    }

}