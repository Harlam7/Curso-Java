class UberPool extends CarBasic {
    
    public UberPool(String license, Account driver, String brand, String model) {

        super(license, driver, brand, model);

    }

}
