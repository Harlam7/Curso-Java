import java.util.ArrayList;

public class Route {
    Integer id;
    ArrayList<Double> start;
    ArrayList<Double> end;
}
