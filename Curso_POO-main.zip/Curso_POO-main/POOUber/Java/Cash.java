public class Cash extends Payments {

    public Cash(Integer id) {
        
        super(id);

    }
    
}
