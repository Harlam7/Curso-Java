<?php

class Payment{
  public $id;
}
?>