<?php

classRoute{
  public $id;
  public $start = [];
  public $end = [];
}
?>