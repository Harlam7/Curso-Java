from carAdvanced import CarAdvanced

class UberSUV(CarAdvanced):
    def __init__(self, license, driver, typeCarAccepted, seatsMaterial):
        super(UberSUV, self).__init__(license, driver, typeCarAccepted, seatsMaterial)