from carAdvanced import CarAdvanced

class UberBlack(CarAdvanced):
    def __init__(self, license, driver, typeCarAccepted, seatsMaterial):
        super(UberBlack, self).__init__(license, driver, typeCarAccepted, seatsMaterial)