from carBasic import CarBasic

class UberPool(CarBasic):
    def __init__(self, license, driver, brand, model):
        super(UberPool, self).__init__(license, driver, brand, model)