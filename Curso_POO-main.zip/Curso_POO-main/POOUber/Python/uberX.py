from carBasic import CarBasic

class UberX(CarBasic):
    def __init__(self, license, driver, brand, model):
        super(UberX, self).__init__(license, driver, brand, model)