class Person {
    String name = "";
    
    void walk () {
        
    }
}