class UberBlack extends UberAdvanced {
    public UberBlack (Integer id, String license, Account driver, Integer passengers, String typeCarAccepted, String seatsMaterial) {
        super(id, license, driver, passengers, typeCarAccepted, seatsMaterial);
    }
}