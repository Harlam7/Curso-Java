class Driver extends Account {
    public Driver (Integer id, String name, String document, String email, String password) {
        super(id, name, document, email, password);
    }
}