class UberX extends UberBasic {
    public UberX (Integer id, String license, Account driver, Integer passengers, String brand, String model) {
        super(id, license, driver, passengers, brand, model);
    }
}