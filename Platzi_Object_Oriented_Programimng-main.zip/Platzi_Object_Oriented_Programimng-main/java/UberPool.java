class UberPool extends UberBasic {
    public UberPool (Integer id, String license, Account driver, Integer passengers, String brand, String model) {
        super(id, license, driver, passengers, brand, model);
    }
}