<?php
class Person {
        $name = "";

        function walk () {
            
        }
    }
?>