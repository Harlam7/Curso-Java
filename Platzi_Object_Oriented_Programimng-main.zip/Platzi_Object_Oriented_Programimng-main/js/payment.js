class Payment {
    constructor (id) {
        this.id = id
    }
}