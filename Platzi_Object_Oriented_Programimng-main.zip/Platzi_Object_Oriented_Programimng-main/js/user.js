class User extends Account {
    constructor (id, name, doc, email, password) {
        super(id, name, doc, email, password);
    }
}