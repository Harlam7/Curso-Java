class UberX extends UberBasic {
    constructor (id, license, driver, passengers, brand, model) {
        super(id, license, driver, passengers, brand, model);
    }
}