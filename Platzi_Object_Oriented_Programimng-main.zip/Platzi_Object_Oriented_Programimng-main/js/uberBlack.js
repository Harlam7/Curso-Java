class UberBlack extends UberAdvanced {
    constructor (id, license, driver, passengers, typeCarAccepted, seatsMaterial) {
        super(id, license, driver, passengers, typeCarAccepted, seatsMaterial);
    }
}