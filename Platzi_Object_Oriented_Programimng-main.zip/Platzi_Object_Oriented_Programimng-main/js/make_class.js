class person {
    constructor(name) {
        this.name = "";
    }

    walk() {

    }
}

