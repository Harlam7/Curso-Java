class Payment:
    id = int

    def __init__ (self, id) -> None:
        self.id = id