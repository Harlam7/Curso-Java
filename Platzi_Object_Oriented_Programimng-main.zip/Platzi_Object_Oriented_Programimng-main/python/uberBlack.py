from uberAdvanced import UberAdvanced

class UberBlack (UberAdvanced):
    def __init__ (self, id, license, driver, passengers, typeCarAccepted, seatsMaterial):
        super().__init__(id, license, driver, passengers, typeCarAccepted, seatsMaterial)
    