class Person:
    name = ""

    def walk ():
        pass