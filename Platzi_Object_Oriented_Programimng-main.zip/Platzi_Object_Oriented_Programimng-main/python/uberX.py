from uberBasic import UberBasic

class UberX (UberBasic):
    def __init__ (self, id, license, driver, passengers, brand, model):
        super().__init__(id, license, driver, passengers, brand, model)