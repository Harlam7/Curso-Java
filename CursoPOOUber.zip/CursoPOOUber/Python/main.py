# para iniciar el main
# ls --> para ver a cual carpeta
# cd python
# py main.py

from car import Car
from account import Account
from UberX import UberX
from user import User

if __name__ == "__main__":
    print("buenas buenas")

    car = Car("ZXC123", Account("Nico", "ZXC123"))
    print(vars(car))
    print(vars(car.driver))

    print("Car: ")
    car = Car("ASD123", Account("Nico Duque", "1", "nico@gmail.com", "123"))
    print(vars(car))
    print(vars(car.driver))

    print("UberX: ")
    uberX = UberX("QWE123", Account("Juli Ortiz", "2", "juli@gmail.com", "456"), "Toyota", "Corolla")
    print(vars(uberX))
    print(vars(uberX.driver))

    print("User: ")
    user = User("ZXC123", Account("Natilla Duque", "3", "natilla@gmail.com"))
    print(vars(user))
    print(vars(user.driver))
