from account import Account

class Car:
    id = int
    license = str
    driver = Account('','')
    passenger = int

    def __init__(self, license, driver,
    email, password
     ):
        self.license = license
        self.driver = driver
        self.email = email
        self.password = password