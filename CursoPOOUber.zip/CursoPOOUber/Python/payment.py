class Payment:
    id = int