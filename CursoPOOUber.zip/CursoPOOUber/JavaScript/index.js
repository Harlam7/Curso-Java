document.write("Hola mundo");

var car = new Car("ASD123", new Account("Nico Duque", "ASD123"))
car.passenger = 4;
car.printDataCar();

var car = new UberX("QWE123", new Account("Juli Ortiz", "QWE123"), "Chevrolet", "Spark")
car.passenger = 4;
car.printDataCar();