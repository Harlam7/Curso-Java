function Account(name, document) {
    this.id;
    this.name = name;
    this.document = document;
    this.email;
    this.password;
}