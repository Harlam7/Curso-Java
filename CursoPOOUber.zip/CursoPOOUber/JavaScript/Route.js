function Account() {
    this.id;
    this.init;
    this.end;
}