<?php
echo '<p>Hola mundo</p>';

require_once('Car.php');
require_once('Account.php');
require_once('UberX.php');
require_once('UberPool.php');

// $car = new Car("ASD123", new Account("Nico Duque", "ASD123"));
// $car->__printDataCar();

$uberX = new UberX("ASD123", new Account("Nico Duque", "ASD123"), "Chevrolet", "Spark");
$uberX->printDataCar();

$uberPool = new UberPool("QWE123", new Account("Juli Ortiz", "QWE123"), "KIA", "Picanto");
$uberPool->printDataCar();

?>