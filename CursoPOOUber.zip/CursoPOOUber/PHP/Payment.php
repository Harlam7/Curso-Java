<?php
class Account {
    public $id = integer;
}
