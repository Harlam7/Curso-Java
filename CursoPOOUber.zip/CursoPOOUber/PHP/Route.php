<?php
class Route {
    public $id = integer;
    public $start = float;
    public $end = float;
}
