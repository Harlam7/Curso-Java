package Java;

class Payment {
    Integer id;
}
