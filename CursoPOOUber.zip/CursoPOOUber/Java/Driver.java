package Java;

class Driver extends Account{
    public Driver(String name, String document, String email, String password){
        super(name, document, email, password);
    }

    void printDataUser() {
        System.out.println("Document driver: " + document + "Name  driver:" + name
        + "Email: " + email + "Password: " + password);
    }
    
}
