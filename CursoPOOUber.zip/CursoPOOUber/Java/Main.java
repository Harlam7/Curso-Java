package Java;

class Main {
    public static void main(String[] args) {
        System.out.println("buenas buenas");

        // crear el objeto
        System.out.println("Car...");
        Car car = new Car("ASD123", new Account("Nico Duque", "1",
        "nico@gmail.com", "123456"));
        car.passenger = 4;
        car.printDataCar();

        System.out.println("UberX...");
        UberX uberx = new UberX("QWE123", new Account("Juli Ortiz", "2",
         "juli@gmail.com", "123456"), "Toyota", "Corolla");
        uberx.printDataUberx();

        // UberX uberX = new UberX("QWE123", new Account("Juli Ortiz", "QWE123",
        // "juli@gmail.com", "123456"));
        // uberX.passenger = 3;
        // uberX.printDataCar();
    }
}